import { FaTimes } from 'react-icons/fa';
import { useGlobalContext } from './context';
import { useEffect, useRef } from 'react';

const Modal = () => {
  const { isModalOpen, closeModal } = useGlobalContext();
  const modalRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        closeModal();
      }
    };

    if (isModalOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isModalOpen, closeModal]);

  if (!isModalOpen) {
    return null;
  }

  return (
    <div className='modal-overlay'>
      <div className='modal-container' ref={modalRef}>
        <h3>modal content</h3>

        <button className='close-modal-btn' onClick={closeModal}>
          <FaTimes />
        </button>
      </div>
    </div>
  );
};

export default Modal;